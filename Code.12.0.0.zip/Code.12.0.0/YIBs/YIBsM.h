#define FLUXNET
#define ACTIVE_GROWTH
#define RESTART_CPOOLS
#define YIBS_1D_DIAG










